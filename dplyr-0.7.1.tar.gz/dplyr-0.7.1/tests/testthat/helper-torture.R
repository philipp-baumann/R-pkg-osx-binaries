with_gctorture2 <- withr::with_(gctorture2)
